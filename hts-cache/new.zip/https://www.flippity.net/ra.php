<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Randomizer on Flippity.net</title>
<LINK href='https://fonts.googleapis.com/css?family=Varela+Round' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Archivo+Narrow' rel='stylesheet' type='text/css'>
<LINK rel=stylesheet href="ra-Style.css">
<LINK rel="icon" type="image/png" href="favicon.png">

<SCRIPT>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-23823535-6', 'flippity.net');
  ga('send', 'pageview');
</SCRIPT>


</head>

<BODY bgcolor="#999999" text="#000000">
<TABLE id="fullScreen" onclick='closeZoom()'><TR><TD><DIV id="bigResult" TITLE="Click to clear"></DIV></TD></TR></TABLE>
<TABLE width="100%" height="100%" cellpadding="0" cellspacing="0" border="0" align="center">
	<TR ID="instructions" STYLE="display: none;"><TD align="center"><A HREF="Randomizer.htm" TARGET="_blank">Want to Make Your Own Randomizer?</A></TD></TR>
	<TR height="1">
    <TD bgcolor="#99a">
    <DIV STYLE="width: 728px; margin: 0px auto;">  
		<DIV Class="logo"><A href="https://www.flippity.net/"><IMG src="images/Flippity-Logo-White.png" alt="Flippity.net" width="100" height="43" border="0" align="left"></A></DIV>
		<H1 id="title">Randomizer</H1>
     </DIV>
    </TD>
  </TR>
  <TR valign="middle">
    <TD align="center" valign="middle">

<SCRIPT type="text/javascript">

	var pageURL = window.location.href
	var encodedURL = encodeURIComponent(pageURL)

	var preLoads = new Array()
	var pl = 0

	function preLoad(img) {
		preLoads[pl] = new Image()
		preLoads[pl].src = img
		pl++
		}

	var content = []
	for (var c=0; c<10; c++) {	
		content[c] = []
		}
	var numRows = []
	var numCols = 1

	var docTitle = "Randomizer on Flippity.net"
	var pageTitle = "Randomizer"
	var refer = ""
	var cardSide = ""	
	var terms = ""
	var loadError = true

	function loadSSContent(json) {

		sheetTitle = json.feed.title.$t
		if (sheetTitle != "Demo") {
			docTitle = sheetTitle + " Randomizer on Flippity.net"
			pageTitle = sheetTitle + " Randomizer"
			}
		encodedDocTitle = encodeURIComponent(docTitle)

		if (refer != "" || cardSide != "" || terms !="") { // coming from somewhere other than Bingo template

			var source = ""
		
			if (refer == "r") { // coming from Random Name Picker
				source = "name"
				}
			else if (cardSide != "") { // coming from Flashcards
				if (cardSide == 2) {
					source = "side2"
					}
				else {
					source = "side1"
					}
				}
			else if (terms != "") { // coming from Bingo
				if (terms == 2) {
					source = "altterms"
					}
				else {
					source = "terms"
					}
				}

			
			// Load content
			for (i=0;i<json.feed.entry.length;i++) {			
				content[0][i] = json.feed.entry[i]['gsx$' + source]['$t']
				}			

			// Remove multimedia answers and prep content
			for (i=0; i<content[0].length; i++) {
				var checkTrm = content[0][i].toLowerCase()
				if (checkTrm.indexOf("youtu.be") > -1 || checkTrm.indexOf("vocaroo.com/i/") > -1 || checkTrm.indexOf("https://voca.ro/") > -1 || checkTrm.indexOf("desmos.com/calculator/") > -1) {
					content[0].splice(i,1)
					i--
					}
				else {
					content[0][i] = prepContent(content[0][i])
					}

				}
			
			if (terms != "" || refer != "") { // coming from Bingo or Random Name Picker
				content[0].unshift("") // add empty value to beginning of array since there is no header
				}
			numRows[0] = content[0].length - 1
			}
		
		else { // terms coming from Randomizer template
			var tmp = [] // temp array to hold terms
			for (var r=0; r<json.feed.entry.length; r++) {			
				tmp[0] = json.feed.entry[r].gsx$column1.$t
				tmp[1] = json.feed.entry[r].gsx$column2.$t
				tmp[2] = json.feed.entry[r].gsx$column3.$t
				tmp[3] = json.feed.entry[r].gsx$column4.$t
				tmp[4] = json.feed.entry[r].gsx$column5.$t
				tmp[5] = json.feed.entry[r].gsx$column6.$t
				tmp[6] = json.feed.entry[r].gsx$column7.$t
				tmp[7] = json.feed.entry[r].gsx$column8.$t
				tmp[8] = json.feed.entry[r].gsx$column9.$t
				tmp[9] = json.feed.entry[r].gsx$column10.$t
				
				for (var c=0; c<10; c++) {	
					if (tmp[c] != "" && typeof tmp[c] != 'undefined') {
						content[c][r] = prepContent(tmp[c])
						}
					else {
						content[c][r] = ""
						}
					}
				}
	
			//determine length of each column
			for (var c=0; c<10; c++) {
				numRows[c] = 0
				for (var r=1; r<content[c].length; r++) {
					if (content[c][r] != "") {
						numRows[c]++
						}
					else {
						break
						}
					}
				}
	
			//determine number of columns
			numCols = numRows.indexOf(0)
			if (numCols == -1) { numCols = 10 }

			}

		loadError = false
		}

	function loadWebContent() {
		var rawTerms = ""
			rawTerms = rawTerms.split(",")
			rawTerms.unshift("") // add empty value to beginning of array since there is no header
			numRows[0] = rawTerms.length-1
			for (i=0; i<rawTerms.length; i++) {
				content[0][i] = prepContent(rawTerms[i])
				}
		loadError = false
		}

	function prepContent(trm) {

		var url = ""
		
		if (trm.toLowerCase().indexOf("[[link:") > -1) {
            url = trm.match(/\[\[Link:(.*?)\]\]/i)[1]
			trm = trm.replace(/\[\[Link:(.*?)\]\]/i,"").trim()
			}

		var picFormats = new Array(".gif",".png",".jpg",".jpeg",".webp")
		var	otherFormats = new Array("https://equatio-","https://docs.google.com/drawings")

		for (j=0; j<picFormats.length; j++) {
			if (trm.slice(0,4) == "http" && trm.toLowerCase().slice(-1*picFormats[j].length) == picFormats[j]) {
				preLoad(trm)
				trm = "<IMG SRC='" + trm + "' class='pic'>"
				}
			}

		for (j=0; j<otherFormats.length; j++) {
			if (trm.slice(0,otherFormats[j].length) == otherFormats[j]) {
				preLoad(trm)
				trm = "<IMG SRC='" + trm + "' class='pic'>"
				}
			}

		if (url != "") {
			preppedTrm = "<DIV><A HREF='" + url + "' TARGET='_blank'>" + trm + "</A></DIV>"
			}
		else {
			preppedTrm = "<DIV>" + trm + "</DIV>"
			}
		
		return preppedTrm
		}

    </SCRIPT>

<SCRIPT type='text/javascript' src='https://spreadsheets.google.com/feeds/list//1/public/values?alt=json-in-script&callback=loadSSContent'></SCRIPT>
	<SCRIPT type="text/javascript">
        if (loadError) {
            window.location.replace("https://www.flippity.net/error.php?k=")
            }
    </SCRIPT>
    
<TABLE border="0" cellpadding="0" cellspacing="0">
<TR>
	<TD></TD>
    <TD id="h1"><DIV id="h1Text" class="header"></DIV></TD>
    <TD id="h2"><DIV id="h2Text" class="header"></DIV></TD>
    <TD id="h3"><DIV id="h3Text" class="header"></DIV></TD>
    <TD id="h4"><DIV id="h4Text" class="header"></DIV></TD>
    <TD id="h5"><DIV id="h5Text" class="header"></DIV></TD>
    <TD id="h6"><DIV id="h6Text" class="header"></DIV></TD>
    <TD id="h7"><DIV id="h7Text" class="header"></DIV></TD>
    <TD id="h8"><DIV id="h8Text" class="header"></DIV></TD>
    <TD id="h9"><DIV id="h9Text" class="header"></DIV></TD>
    <TD id="h10"><DIV id="h10Text" class="header"></DIV></TD>
	<TD></TD>
	<TD></TD>
</TR>
<TR>
	<TD></TD>
    <TD id="r1"><DIV id="r1Text" class="result">&nbsp;</DIV></TD>
    <TD id="r2"><DIV id="r2Text" class="result">&nbsp;</DIV></TD>
    <TD id="r3"><DIV id="r3Text" class="result">&nbsp;</DIV></TD>
    <TD id="r4"><DIV id="r4Text" class="result">&nbsp;</DIV></TD>
    <TD id="r5"><DIV id="r5Text" class="result">&nbsp;</DIV></TD>
    <TD id="r6"><DIV id="r6Text" class="result">&nbsp;</DIV></TD>
    <TD id="r7"><DIV id="r7Text" class="result">&nbsp;</DIV></TD>
    <TD id="r8"><DIV id="r8Text" class="result">&nbsp;</DIV></TD>
    <TD id="r9"><DIV id="r9Text" class="result">&nbsp;</DIV></TD>
    <TD id="r10"><DIV id="r10Text" class="result">&nbsp;</DIV></TD>
	<TD></TD>
	<TD  ALIGN="center" rowspan="2"><input type="checkbox" ID="autoZoom" TITLE="Auto Zoom"> <DIV onclick="zoom()" STYLE="cursor: pointer; display: inline-block;"><img src="images/Button-Zoom.png" width="20" height="20" TITLE="Zoom in on Result"></DIV></TD>
</TR>
<TR ALIGN="center">
  <TD></TD>
  <TD id="x1" STYLE="visibility: hidden;"><DIV onClick='removeSide(1)' class='button narrow' TITLE="Remove Item from Wheel"><img src="images/Button-Remove.png"></DIV></TD>
  <TD id="x2" STYLE="visibility: hidden;"><DIV onClick='removeSide(2)' class='button narrow' TITLE="Remove Item from Wheel"><img src="images/Button-Remove.png"></DIV></TD>
  <TD id="x3" STYLE="visibility: hidden;"><DIV onClick='removeSide(3)' class='button narrow' TITLE="Remove Item from Wheel"><img src="images/Button-Remove.png"></DIV></TD>
  <TD id="x4" STYLE="visibility: hidden;"><DIV onClick='removeSide(4)' class='button narrow' TITLE="Remove Item from Wheel"><img src="images/Button-Remove.png"></DIV></TD>
  <TD id="x5" STYLE="visibility: hidden;"><DIV onClick='removeSide(5)' class='button narrow' TITLE="Remove Item from Wheel"><img src="images/Button-Remove.png"></DIV></TD>
  <TD id="x6" STYLE="visibility: hidden;"><DIV onClick='removeSide(6)' class='button narrow' TITLE="Remove Item from Wheel"><img src="images/Button-Remove.png"></DIV></TD>
  <TD id="x7" STYLE="visibility: hidden;"><DIV onClick='removeSide(7)' class='button narrow' TITLE="Remove Item from Wheel"><img src="images/Button-Remove.png"></DIV></TD>
  <TD id="x8" STYLE="visibility: hidden;"><DIV onClick='removeSide(8)' class='button narrow' TITLE="Remove Item from Wheel"><img src="images/Button-Remove.png"></DIV></TD>
  <TD id="x9" STYLE="visibility: hidden;"><DIV onClick='removeSide(9)' class='button narrow' TITLE="Remove Item from Wheel"><img src="images/Button-Remove.png"></DIV></TD>
  <TD id="x10" STYLE="visibility: hidden;"><DIV onClick='removeSide(10)' class='button narrow'><img src="images/Button-Remove.png"></DIV></TD>
  <TD></TD>
  </TR>
<TR>
	<TD><img src="images/Wheel-Indicator-Lt.png" id="ltEdge" width="30" height="404"></TD>
	<TD id="c1" class="column" align="center"><div class="shading"></div><div class="scene" id="scene1"><div class="wheel" id="wheel1"></div></div></TD>
    <TD id="c2" class="column"><div class="shading"></div><div class="scene" id="scene2"><div class="wheel" id="wheel2"></div></div></TD>
    <TD id="c3" class="column"><div class="shading"></div><div class="scene" id="scene3"><div class="wheel" id="wheel3"></div></div></TD>
    <TD id="c4" class="column"><div class="shading"></div><div class="scene" id="scene4"><div class="wheel" id="wheel4"></div></div></TD>
    <TD id="c5" class="column"><div class="shading"></div><div class="scene" id="scene5"><div class="wheel" id="wheel5"></div></div></TD>
    <TD id="c6" class="column"><div class="shading"></div><div class="scene" id="scene6"><div class="wheel" id="wheel6"></div></div></TD>
    <TD id="c7" class="column"><div class="shading"></div><div class="scene" id="scene7"><div class="wheel" id="wheel7"></div></div></TD>
    <TD id="c8" class="column"><div class="shading"></div><div class="scene" id="scene8"><div class="wheel" id="wheel8"></div></div></TD>
    <TD id="c9" class="column"><div class="shading"></div><div class="scene" id="scene9"><div class="wheel" id="wheel9"></div></div></TD>
    <TD id="c10" class="column"><div class="shading"></div><div class="scene" id="scene10"><div class="wheel" id="wheel10"></div></div></TD>
	<TD><img src="images/Wheel-Indicator-Rt.png" id="rtEdge" width="30" height="404" STYLE="margin-right: 30px;"></TD>
	<TD ALIGN="center" id="side">
    <DIV onClick="nextAll(-1)" TITLE="Move All Up 1" class="button"><IMG SRC="images/Button-Up-Blue-Sm.png"></DIV><DIV onClick="nextAll(1)" TITLE="Move All Down 1" class="button"><IMG SRC="images/Button-Down-Blue-Sm.png"></DIV><BR>
    <DIV onClick="spinAll()" TITLE="Spin All Wheels" class="button wide"><IMG SRC="images/Button-Spin.png"></DIV>
     </TD>
</TR>
<TR align="center">
	<TD></TD>
    <TD id="b1">
    <DIV onClick="next(1,-1)" TITLE="Move Up 1" class="button"><IMG SRC="images/Button-Up-Blue-Sm.png"></DIV><DIV onClick="next(1,1)" TITLE="Move Down 1" class="button"><IMG SRC="images/Button-Down-Blue-Sm.png"></DIV><BR>
    <DIV onClick="spin(1)" TITLE="Spin Wheel" class="button wide"><IMG SRC="images/Button-Spin-Sm.png"></DIV>
    </TD>
    <TD id="b2">
    <DIV onClick="next(2,-1)" TITLE="Move Up 1" class="button"><IMG SRC="images/Button-Up-Blue-Sm.png"></DIV><DIV onClick="next(2,1)" TITLE="Move Down 1" class="button"><IMG SRC="images/Button-Down-Blue-Sm.png"></DIV><BR>
    <DIV onClick="spin(2)" TITLE="Spin Wheel" class="button wide"><IMG SRC="images/Button-Spin-Sm.png"></DIV>
    </TD>
    <TD id="b3">
    <DIV onClick="next(3,-1)" TITLE="Move Up 1" class="button"><IMG SRC="images/Button-Up-Blue-Sm.png"></DIV><DIV onClick="next(3,1)" TITLE="Move Down 1" class="button"><IMG SRC="images/Button-Down-Blue-Sm.png"></DIV><BR>
    <DIV onClick="spin(3)" TITLE="Spin Wheel" class="button wide"><IMG SRC="images/Button-Spin-Sm.png"></DIV>
    </TD>
    <TD id="b4">
    <DIV onClick="next(4,-1)" TITLE="Move Up 1" class="button"><IMG SRC="images/Button-Up-Blue-Sm.png"></DIV><DIV onClick="next(4,1)" TITLE="Move Down 1" class="button"><IMG SRC="images/Button-Down-Blue-Sm.png"></DIV><BR>
    <DIV onClick="spin(4)" TITLE="Spin Wheel" class="button wide"><IMG SRC="images/Button-Spin-Sm.png"></DIV>
    </TD>
    <TD id="b5">
    <DIV onClick="next(5,-1)" TITLE="Move Up 1" class="button"><IMG SRC="images/Button-Up-Blue-Sm.png"></DIV><DIV onClick="next(5,1)" TITLE="Move Down 1" class="button"><IMG SRC="images/Button-Down-Blue-Sm.png"></DIV><BR>
    <DIV onClick="spin(5)" TITLE="Spin Wheel" class="button wide"><IMG SRC="images/Button-Spin-Sm.png"></DIV>
    </TD>
    <TD id="b6">
    <DIV onClick="next(6,-1)" TITLE="Move Up 1" class="button"><IMG SRC="images/Button-Up-Blue-Sm.png"></DIV><DIV onClick="next(6,1)" TITLE="Move Down 1" class="button"><IMG SRC="images/Button-Down-Blue-Sm.png"></DIV><BR>
    <DIV onClick="spin(6)" TITLE="Spin Wheel" class="button wide"><IMG SRC="images/Button-Spin-Sm.png"></DIV>
    </TD>
    <TD id="b7">
    <DIV onClick="next(7,-1)" TITLE="Move Up 1" class="button"><IMG SRC="images/Button-Up-Blue-Sm.png"></DIV>
    <DIV onClick="next(7,1)" TITLE="Move Down 1" class="button"><IMG SRC="images/Button-Down-Blue-Sm.png"></DIV><BR>
    <DIV onClick="spin(7)" TITLE="Spin Wheel" class="button wide"><IMG SRC="images/Button-Spin-Sm.png"></DIV>
    </TD>
    <TD id="b8">
    <DIV onClick="next(8,-1)" TITLE="Move Up 1" class="button"><IMG SRC="images/Button-Up-Blue-Sm.png"></DIV><DIV onClick="next(8,1)" TITLE="Move Down 1" class="button"><IMG SRC="images/Button-Down-Blue-Sm.png"></DIV><BR>
    <DIV onClick="spin(8)" TITLE="Spin Wheel" class="button wide"><IMG SRC="images/Button-Spin-Sm.png"></DIV>
    </TD>
    <TD id="b9">
    <DIV onClick="next(9,-1)" TITLE="Move Up 1" class="button"><IMG SRC="images/Button-Up-Blue-Sm.png"></DIV>
    <DIV onClick="next(9,1)" TITLE="Move Down 1" class="button"><IMG SRC="images/Button-Down-Blue-Sm.png"></DIV><BR>
    <DIV onClick="spin(9)" TITLE="Spin Wheel" class="button wide"><IMG SRC="images/Button-Spin-Sm.png"></DIV>
    </TD>
    <TD id="b10">
    <DIV onClick="next(10,-1)" TITLE="Move Up 1" class="button"><IMG SRC="images/Button-Up-Blue-Sm.png"></DIV><DIV onClick="next(10,1)" TITLE="Move Down 1" class="button"><IMG SRC="images/Button-Down-Blue-Sm.png"></DIV><BR>
    <DIV onClick="spin(10)" TITLE="Spin Wheel" class="button wide"><IMG SRC="images/Button-Spin-Sm.png"></DIV>
    </TD>
	<TD></TD>
	<TD>&nbsp;</TD>
</TR>
</TABLE>

	<SCRIPT type="text/javascript">

	var spun = false	
	
	function loadTerms() {
		radius = 200
		minW = 100
		wheels = []
		sides = []
		sideCounts = []
		thetas = []
		maxWs = []
		rads = []
		sideHeights = []
		zTrans = []
		selectedSides = ['',0,0,0,0,0,0,0,0,0,0] // total sides the wheel needs to spin
		selectedResults = [] // side that wheel will stop on
		baseColor = Math.floor(Math.random() * 361)
		setSingleColColors()
		}

	function loadHeadings() { // load headings and hide unused columns
		for (var c=1; c<=10; c++) {
			if (c <= numCols) {
				var col = c-1
				document.getElementById('h'+c+'Text').innerHTML = content[col][0]
				document.getElementById('h'+c).style.width = maxWs[c] + 'px'
				}
			else {
				document.getElementById('h'+c).style.display = "none"
				document.getElementById('r'+c).style.display = "none"
				document.getElementById('x'+c).style.display = "none"
				document.getElementById('c'+c).style.display = "none"
				document.getElementById('b'+c).style.display = "none"
				}
			maxWs[c] = Math.max(minW,document.getElementById('h' + c).offsetWidth)
			}
		}

	function setSingleColColors() {
		singleColColors = []
		for (var r=1; r<=numRows[0]; r++) {
			singleColColors[r] = baseColor + (360/numRows[0]) * r
			}
		}

	function loadWheel(wheel) {
		shades = document.getElementsByClassName("shading")
		var cTerms = ""
		var col = wheel-1
		var color = baseColor + (360/numCols) * wheel
			if (color > 360) { color -= 360 }
		for (var r=1; r<=numRows[col]; r++) {
			if (numCols == 1) {
				minW = 250
				color = singleColColors[r]
				}
			cTerms += "<div class='wheelSide" + wheel + "' STYLE='background: hsl(" + color + ", 70%, 50%)'>" + content[col][r] + "</div>"
			}
		document.getElementById('wheel' + wheel).innerHTML = cTerms
		wheels[wheel] = document.querySelector('#wheel' + wheel)
		sides[wheel] = wheels[wheel].querySelectorAll('.wheelSide' + wheel)
		sideCounts[wheel] = sides[wheel].length
		thetas[wheel] = 360 / sideCounts[wheel]
		rads[wheel] = thetas[wheel] * Math.PI/360;
		if (sideCounts[wheel] > 1) {
			sideHeights[wheel] = radius * Math.sin(rads[wheel]) * 2 // determine height of each side
			}
		else {
			sideHeights[wheel] = radius * 2 // only one side
			document.getElementById('r' + wheel + 'Text').innerHTML = content[col][1]
			document.getElementById('b' + wheel).style.visibility = "hidden"
			}
		
		zTrans[wheel] = radius * Math.cos(rads[wheel])
		
		// determine max width of sides
		for (var r=0; r<sideCounts[wheel]; r++) {
			if (sides[wheel][r].offsetWidth > maxWs[wheel]) {
				maxWs[wheel] = Math.max(sides[wheel][r].offsetWidth,minW)
				}
			}

		// resize height and width of each side and rotate
		for (var r=0; r<sideCounts[wheel]; r++) {
			sides[wheel][r].style.height = sideHeights[wheel] + "px" // resize height of side
			sides[wheel][r].style.lineHeight = sideHeights[wheel] + "px" // resize height of text
			sides[wheel][r].style.width = Math.max(maxWs[wheel],0) + "px" // resize width of side
			if (sideCounts[wheel] > 1) {
				var side = sides[wheel][r];
				var sideAngle = thetas[wheel] * r;
				side.style.transform = "rotateX(" + sideAngle + "deg) translateZ(" + zTrans[wheel] + "px)" // rotate sides into position
				}
			}

		if (sideCounts[wheel] > 4 && numCols > 1) {
			shades[col].style.width = maxWs[wheel] + 2 + "px" // resize all shades to max width
			shades[col].style.display = "block"
			}
		
		document.getElementById('scene' + wheel).style.width = maxWs[wheel] + 4 + "px" // resize all scenes to max width including 2 pixels border on each side
		document.getElementById('scene' + wheel).style.height = sideHeights[wheel] + "px" // resize all scenes to side height
		document.getElementById('scene' + wheel).style.marginTop = radius - sideHeights[wheel]/2 + "px" // center scenes vertically
		document.getElementById('scene' + wheel).style.marginBottom = radius - sideHeights[wheel]/2 + "px"

		}

	function loadAllWheels() {
		for (var c=1; c<=numCols; c++) {
			loadWheel(c)
			}
		if (numCols == 1) { // single wheel
			shades[0].style.display = "none"
			var perspective = 1000
			var viewWidth = ((perspective / 2 + 119) * maxWs[1]) / (perspective / 2)
			document.getElementById('scene1').style.perspective = perspective + "px" // perspective on single wheel
			document.getElementById('ltEdge').style.marginRight = "0px"
			document.getElementById('rtEdge').style.marginLeft = "0px"
			document.getElementById('c1').style.backgroundColor = "transparent"
			document.getElementById('c1').style.width = viewWidth + "px"
			document.getElementById('h1').style.display = "none"
			document.getElementById('side').style.display = "none"
			}
		}

	function spin(wheel) {
		spinTime = 3 // 3 seconds for full spin
		var spin = Math.floor(Math.random() * (3*sideCounts[wheel])) + sideCounts[wheel] // random side between 1 and 3 times around the wheel
		selectedSides[wheel] += spin
		rotate(wheel)
		}
	
	function spinAll() {
		for (var c=1; c<=numCols; c++) {
			if (sideCounts[c] > 1) {
				spin(c)
				}
			}
		}

	function next(wheel,dir) {
		spinTime = .4 // .4 seconds to move one side
		selectedSides[wheel] += dir
		rotate(wheel)
		}
	
	function nextAll(dir) {
		for (var c=1; c<=numCols; c++) {
			if (sideCounts[c] > 1) {
				next(c,dir)
				}
			}
		}

	function rotate(wheel) {
		spun = true
		document.getElementById('bigResult').innerHTML = ""
		document.getElementById('wheel' + wheel).style.transitionDuration = spinTime + 's'
		document.getElementById('r' + wheel + 'Text').innerHTML = "&nbsp;"
		document.getElementById('x' + wheel).style.visibility = "hidden"
		var angle = thetas[wheel] * selectedSides[wheel] * -1;
		wheels[wheel].style.transform = "rotateX(" + angle + "deg)";
		selectedResults[wheel] = selectedSides[wheel] % sideCounts[wheel]
		if (selectedResults[wheel] < 0) {
			selectedResults[wheel] += sideCounts[wheel]
			}
		setTimeout(function() {
			var res = sides[wheel][selectedResults[wheel]].innerHTML
			document.getElementById('r' + wheel + 'Text').innerHTML = res
			document.getElementById('bigResult').innerHTML += res
			if (document.getElementById("autoZoom").checked) { zoom() }
			document.getElementById('x' + wheel).style.visibility = "visible"
			}, (spinTime * 1000));
		}

	function removeSide(wheel) {
		// rotate back to 1st side immediately
		spinTime = 0
		document.getElementById('wheel' + wheel).style.transitionDuration = '0s'
		wheels[wheel].style.transform = "rotateX(0deg)"
		
		// remove selected term from content
		var col = wheel-1
		content[col].splice(selectedResults[wheel]+1,1)
		singleColColors.splice(selectedResults[wheel]+1,1) // for single column colors
		numRows[col]--
		selectedResults[wheel] = selectedSides[wheel] % sideCounts[wheel]
		selectedSides[wheel] = selectedResults[wheel]

		// load revised wheel & hide results
		document.getElementById('r' + wheel + 'Text').innerHTML = "&nbsp;"
		loadWheel(wheel)
		document.getElementById('x' + wheel).style.visibility = "hidden"

		// rotate revised wheel back to original wheel's position
		var angle = thetas[wheel] * selectedResults[wheel] * -1
		wheels[wheel].style.transform = "rotateX(" + angle + "deg)"

		}
	
	loadTerms()
	loadHeadings()
	loadAllWheels()

	function zoom() {
		console.log(spun)
		if (spun) {
			document.getElementById('fullScreen').style.display = "table"
			}
		}
		
	function closeZoom() {
		//document.getElementById('bigResult').innerHTML = ""
		document.getElementById('fullScreen').style.display = "none"
		}

    </SCRIPT>

    
    </TD>
  </TR>
  <TR>
    <TD height="1" align="CENTER" valign="MIDDLE">

	<SCRIPT type="text/javascript">
		function showHideShare() {
            if (document.getElementById('share').style.display == 'none') {
                document.getElementById('share').style.display = 'inline'
                }
            else {
                document.getElementById('share').style.display = 'none'
                }
            }
    </SCRIPT>
        
      <BR>
      <P class="share" ><A class="share" href="javascript:showHideShare()" title="Show/Hide Sharing Options"><IMG SRC="images/Share-Icon-Gray.png" width="15" height="16" border="0" align="absmiddle" style="margin-right: 6px;">share</A></P>
     
      <DIV ID="share" style="display: none;">
      
      <IMG src="images/Link-Icon.png" width="16" height="16" hspace="10" align="absmiddle">
        <INPUT id="linkURL" type="text" class="linkBox" onClick="this.select()" value="">
    
        <TABLE align="center" class="shareOptions">
          <TR>
              <TD>
              <script src="https://apis.google.com/js/platform.js" async defer></script>
				<g:sharetoclassroom url="https://www.flippity.net/ra.php?" size="20"></g:sharetoclassroom>
              </TD>
              <TD valign="baseline">
	            <SCRIPT type="text/javascript">document.write("<a href='mailto:?subject=" + encodedDocTitle + "&body=Check out this " + encodedDocTitle + ": " + encodedURL + "' TARGET='_blank'><img src='images/Icon-Email.png' width='22' height='20' border='0' title='Email'></a>")</SCRIPT>
              </TD>
              <TD>
	            <SCRIPT type="text/javascript">
					encodedQRurl = "QR.php?u=" + encodedURL + "&p=" + encodeURIComponent(pageTitle)
					document.write("<a href='" + encodedQRurl + "' target='_blank'><img src='images/Flippity-QR-Code.gif' width='20' height='20' border='0' title='Get QR Code'></a>")
                </SCRIPT>
              </TD>
            <TD>
                <a href="#" class="twitter-share"><IMG SRC="images/Twitter-Button.gif" width="60" height="20" ALT="Tweet"></a>
              <SCRIPT type="text/javascript">
                
                    var getWindowOptions = function() {
                    var width = 500;
                    var height = 350;
                    var left = (window.innerWidth / 2) - (width / 2);
                    var top = (window.innerHeight / 2) - (height / 2);
                    
                    return [
                        'resizable,scrollbars,status',
                        'height=' + height,
                        'width=' + width,
                        'left=' + left,
                        'top=' + top,
                        ].join();
                        };
                    
                    var twitterBtn = document.querySelector('.twitter-share');
                    var shareUrl = 'https://twitter.com/intent/tweet?url=' + encodedURL + '&text=' + encodedDocTitle
                    twitterBtn.href = shareUrl; // 1
                    
                    twitterBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    var win = window.open(shareUrl, 'ShareOnTwitter', getWindowOptions());
                    win.opener = null; // 2
                    });
                    
                </SCRIPT>
            </TD>
       		  <TD>
                <a href="https://docs.google.com/spreadsheets/d/" target="_blank"><img src="images/Google-Sheets-Icon.gif" width="16" height="20" border="0" title="Original Spreadsheet"></a>
              </TD>
          </TR>
        </TABLE>
      </DIV> 

    </TD>
  </TR>
  <TR>
    <TD height="1" align="CENTER" valign="MIDDLE" bgcolor="#99a">
      <P class="copyright">Copyright&copy; 2020 Flippity.net. All Rights Reserved.</P>
    </TD>
  </TR>
 </TABLE>

    <SCRIPT type="text/javascript">
		document.getElementById('linkURL').value = pageURL
		document.title = docTitle
		document.getElementById('title').innerHTML = pageTitle
		if ("" == "11J_rsm32HDtn2Cl5LN8oS_FtiUYChITgxYS6kocJ8sA") { document.getElementById('instructions').style.display = "table-row" }
    </SCRIPT>

</BODY>
</HTML>